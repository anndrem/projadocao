<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Adoção</title>
</head>
<body>
    <h1>Bem-vindo ao Sistema de adoção de cães</h1>
    <a href="cadastrarcao.php">Cadastrar novo cão</a><br><br>
    <a href="listar_cao.php">Listar Cães Disponíveis</a><br><br>
    <a href="listar_adotados.php">Listar Cães Adotados</a><br><br>
    <a href="buscar_caes.php">Buscar Cães</a><br><br>
</body>
</html>